from flask import Flask, render_template, request, redirect, url_for, flash

app = Flask(__name__)
app.secret_key = 'your_secret_key'  # For secure sessions

# Home route rendering the HTML page
@app.route('/')
def home():
    return render_template('index.html')  # Renders the provided HTML

# Example route to handle a form submission (e.g., "Contact" form)
@app.route('/submit_form', methods=['POST'])
def submit_form():
    if request.method == 'POST':
        # Access form data
        name = request.form['name']
        email = request.form['email']
        message = request.form['message']
        
        # Example: Print to console or log, could also save to a database
        print(f'Received message from {name}, Email: {email}, Message: {message}')
        
        flash('Thank you for reaching out! We will get back to you soon.', 'success')
        return redirect(url_for('home'))

if __name__ == '__main__':
    app.run(debug=True)
